#include <stdio.h>

void func_1();

void func_2();
