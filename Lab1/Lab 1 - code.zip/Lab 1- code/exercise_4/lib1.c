#include "lib.h"

void func_1(){
	printf("func 1\n");
}

void func_2(){
	printf("func 2\n");
}
