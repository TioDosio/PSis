typedef struct message_type{
    int funct_type;
    char f_name[100];
    int arg;

} message_type;